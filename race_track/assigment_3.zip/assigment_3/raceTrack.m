%cose da aggiungere: 
% 2: voglio visualizzare ogni 100 episodi
% 4: sistemare colori 

% Parametri del problema
close all
clear
clc

% Definizione della griglia per la pista a forma di "L" PROVA
R = 30; %righe 
C = 26; %colonne 

%costruisco la griglia -> mettila in un altro script
[griglia, coloredGrid] = crea_pista(R,C);

%stati, azioni, stati iniziali e terminali
S = R*C;                %numero totale di caselle della griglia
A = 9;                  %numero di azioni totali:  Azioni possibili = [v_x, v_y] per ognuna posso fare +1, -1, 0, quindi
                        % sono 9 combinazioni azioni = [-1, 0, 1; -1, 0, 1; -1, 0, 1];

% Trova la posizione della linea di partenza (rosso, 3) --> x e y sono
% vettori colonna
[startY, startX] = find(coloredGrid == 3);      % startX e startY conterranno le righe (y) e le colonne (x) in cui si trova la linea di partenza.
statiInizialiX = startX';
statiInizialiY = startY';
% Trova la posizione della linea di arrivo (verde, 2)
[finishY, finishX] = find(coloredGrid == 2);    % finishX e finishY conterranno le righe e le colonne in cui si trova la linea di arrivo.

%velocità iniziali lungo le componenti
vel_x=0;
vel_y=0;


% Parametri di RL
gamma = 1.0;             % Fattore di sconto
alpha = 0.1;             % Tasso di apprendimento
epsilon = 0.1;           % Probabilità di esplorazione
beta=0.999;
numEpisodes = 10000;     % Numero di episodi        

policy = zeros(S, 1);
for s = 1:S
    %riga e colonna dello stato
    [row, colum] = ind2sub([R, C], s); 
    %imposto la policy (casuale) solo sulle caselle valide
    if griglia(row, colum)==1 
        policy(s)=randi(A);
    end
end

%inizializzazione
N = zeros(S, A);
Q = zeros(S, A);        %numero di visite

%per tenere in memoria il numero di iterazioni che ogni episodio impiega per terminare
record_count = []; 


% Monte Carlo on policy Exploring start
for e = 1:numEpisodes
    disp(['episodio numero: ', num2str(e)]);

    % Scelgo lo stato e l'azione iniziale in modo casuale
    s0 = [statiInizialiX(randi([1, 12])), statiInizialiY(1)];
    actions = [];
    rewards = [];
    a1 = 1; % prima azione

    % Inizio l'episodio
    s = s0;
    stati = s0;

    count = 0;

    % Visualizza la griglia iniziale
    if mod(e, 100)==0
        figure(1);
        tempGrid = coloredGrid;          % Copia la griglia di base
        tempGrid(s(2), s(1)) = 4;        % Imposta la cella iniziale a blu (4)
        imagesc(tempGrid);
        colormap([0.5 0.5 0.5; 1 1 1; 0 1 0; 1 0 0; 0 0 1]); % Grigio, Bianco, Verde, Rosso, Blu
        axis equal;
        axis tight;
        title(['Episodio ', num2str(e)]);
        grid on;
        set(gca, 'XTick', 0.5:1:size(griglia, 2)+0.5, ...
                 'YTick', 0.5:1:size(griglia, 1)+0.5, ...
                 'XTickLabel', [], 'YTickLabel', [], ...
                 'GridColor', 'k', 'GridAlpha', 1);
        pause(0.2);  % Pausa per vedere la posizione iniziale
    end
    % Arrivo in uno stato terminale
    while s ~= -1
        count = count + 1;
        
        % Se è la prima azione, la prendo casuale
        if a1
            a = randi(A); 
            a1 = 0;
        else
            % Dalla seconda azione seguo la policy
            linearIndex = sub2ind([R, C], riga, colonna);
            a = policy(linearIndex);

            % Esploro prendendo l'azione casuale
            if rand(1) < epsilon                 
                a = randi(A);
            end       
        end

        % Dallo stato s vado allo stato successivo secondo l'azione a
        [s, r, vel_x, vel_y, riga, colonna] = racetrack_function(s, a, griglia, statiInizialiX, statiInizialiY, R, C, vel_x, vel_y);

        % Aggiorna la griglia visiva con la posizione corrente
        tempGrid = coloredGrid;  % Copia la griglia di base
        tempGrid(riga, colonna) = 4;  % Imposta la cella corrente a blu (4)
        
        % Visualizza la griglia aggiornata
        if mod(e, 100) == 0
            imagesc(tempGrid);
            colormap([0.5 0.5 0.5; 1 1 1; 0 1 0; 1 0 0; 0 0 1]); % Grigio, Bianco, Verde, Rosso, Blu
            axis equal;
            axis tight;
            title(['Episodio ', num2str(e), ', Step ', num2str(count)]);
            grid on;
            set(gca, 'XTick', 0.5:1:size(griglia, 2)+0.5, ...
                     'YTick', 0.5:1:size(griglia, 1)+0.5, ...
                     'XTickLabel', [], 'YTickLabel', [], ...
                     'GridColor', 'k', 'GridAlpha', 1);
            
            % Pausa per animazione
            pause(0.2);
        end
        % Concateno gli stati che visito, le azioni fatte e i reward
        stati = [stati; s]
        actions = [actions, a];
        rewards = [rewards, r]; 
    end

    % Fine episodio
    [finishY, finishX] = find(coloredGrid == 2); % Coordinate della cella di arrivo
    finishStates = sub2ind([R, C], finishY, finishX); % Indici lineari della linea di arrivo

    % Tieni traccia delle iterazioni messe per ogni episodio
    record_count = [record_count, count]; 

    % Aggiornamento di Q di stato-azioni visitate
    G = 0;
    for t = length(rewards):-1:1
        G = rewards(t) + gamma*G; 
        N(stati(t), actions(t)) = N(stati(t), actions(t)) + 1;
        Q(stati(t), actions(t)) = Q(stati(t), actions(t)) + alpha * (G - Q(stati(t), actions(t)));
    end

    if mod(e, 100) == 0
        % Ruota la figura di 270 gradi in modo antiorario per la visualizzazione
        camroll(270);
        clf; % Pulisce la figura precedente
    
        % Calcola le posizioni delle colonne e delle righe
        xx = stati(:, 2); % Colonne (la seconda colonna di 'stati')
        yy = stati(:, 1); % Righe (la prima colonna di 'stati')
        
        % Verifica le dimensioni di xx e yy per essere sicuri che siano corretti
        disp('xx:');
        disp(xx);
        disp('yy:');
        disp(yy);
    
        % Plotta la traiettoria
        figure(2);
        hold on; % Mantieni il grafico per aggiungere più elementi
        plot(xx, yy, 'k', 'LineWidth', 4); % Linea nera per la traiettoria
        
        % Evidenzia la partenza e l'arrivo
        plot(xx(1), yy(1), 'go', 'MarkerFaceColor', 'g'); % Partenza (verde)
        
        
        % Imposta i limiti e la griglia
        xlim([1, C]);
        ylim([1, R]);
        axis equal;
        grid on;
        grid minor;
        
       
        % Aggiungi etichetta agli assi per chiarezza
        xlabel('Colonne');
        ylabel('Righe');
        title(['Traiettoria del percorso (Episodio ', num2str(e), ')']);
        
        % Pausa per vedere la traiettoria
        pause(1); % Pausa per vedere la traiettoria
        
        hold off; % Rilascia il grafico per future aggiunte
    end



end
