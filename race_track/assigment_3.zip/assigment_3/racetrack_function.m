function [sp, r, newvel_x, newvel_y, riga, colonna] = racetrack_function(s, a, griglia, statiInizialiX, statiInizialiY, R, C, vel_x, vel_y)
    % La funzione deve simulare la dinamica del problema: calcolo il nuovo
    % stato, il reward e aggiorno le velocità in conseguenza all'azione
    % scelta e allo stato attuale. 
    % Gestisco poi i casi limite in cui la macchina esce dalla pista o
    % raggiunge lo stato terminale
    
    r = -1; % Reward base
    
    % Aggiornamento delle velocità lungo le componenti x e y
    if numel(a) ~= 1
        error('a deve essere uno scalare.');
    end
    [x, y] = ind2sub([3, 3], a); % Converti l'indice in coordinate azione: il -2 perché voglio centrare la matrice delle azioni intorno allo zero

    newvel_x = max(0, min(5, vel_x + (x - 2))); % Aggiorna e limita vel_x
    newvel_y = max(0, min(5, vel_y + (y - 2))); % Aggiorna e limita vel_y

    % Verifico che le velocità non siano contemporaneamente zero
    if newvel_x == 0 && newvel_y == 0
        newvel_y = randi(2) - 1; % Genera casualmente 0 o 1 per newvel_y
        if newvel_y == 0
            newvel_x = 1; % Se newvel_y è 0, imposta newvel_x a 1
        end
    end

    % Calcolo ora la nuova posizione aggiornando riga e colonna della
    % griglia
    row = s(2); % Stato corrente in coordinate (riga, colonna)
    col = s(1);
    newcol = col + newvel_x; % Nuova colonna basata sulla velocità x
    newrow = row - newvel_y; % Nuova riga basata sulla velocità y, in accordo al sistema di riferimento della griglia
    
    % Controllo degli stati validi
    if newrow >= 1 && newcol >= 1 && newrow <= R && newcol <= C
        % Calcolo la direzione del movimento in termini di passo
        step_x = sign(newvel_x); % Direzione: +1 (avanti), 0 (fermo), -1 (indietro)
        step_y = -sign(newvel_y); % Direzione: -1 (verso l'alto nella griglia)
    
        % Posizione di partenza
        temp_pos_r = row; 
        temp_pos_c = col;
      
        % Spostamento passo-passo per verificare collisioni
        % Ciclo di movimento passo-passo per verificare collisioni
        while temp_pos_r ~= newrow || temp_pos_c ~= newcol
            % Verifica se i nuovi indici sono validi prima di avanzare
            if newrow < 1 || newcol < 1 || newrow > R || newcol > C
                % Se si esce dai limiti della griglia, l'episodio finisce
                disp('Indici fuori dai limiti della griglia durante il movimento');
                sp = [-1, -1]; % Stato terminale (uscita fuori dalla pista)
                r = -1; % Reward negativo per uscita
                newvel_x = 0;
                newvel_y = 0;
                riga = statiInizialiY(randi(length(statiInizialiX))); % Reset velocità
                colonna = statiInizialiX(randi(length(statiInizialiX))); % Stato iniziale
                return;  % Termina l'episodio, tornando al ciclo principale
            end

            
            % Avanza lungo y se necessario
            if temp_pos_r ~= newrow
                temp_pos_r = temp_pos_r + step_y;
            end
        
            % Avanza lungo x se necessario
            if temp_pos_c ~= newcol
                temp_pos_c = temp_pos_c + step_x;
            end
        
            % Controlla collisioni lungo il percorso
            if temp_pos_r >= 1 && temp_pos_r <= R && temp_pos_c >= 1 && temp_pos_c <= C
                if griglia(temp_pos_r, temp_pos_c) == 0
                    % Collisione: resetto lo stato e l'episodio finisce
                    disp('Collisione: resetto lo stato.');
                    sp = [-1, -1]; % Stato terminale per collisione
                    r = -1; % Reward negativo per collisione
                    newvel_x = 0;
                    newvel_y = 0;
                    riga = statiInizialiY(randi(length(statiInizialiX))); % Stato iniziale
                    colonna = statiInizialiX(randi(length(statiInizialiX))); % Stato iniziale
                    return; % Termina l'episodio e passa al successivo
                end
            end
        end
    end
    
    % Verifica se il nuovo stato è terminale o invalido
    if newcol > C && ismember(newrow, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
        % Stato terminale: il veicolo ha superato il traguardo
        sp = [-1, -1]; % Stato terminale (vettore col, row)
        r = 10; % Reward positivo per il traguardo
        riga = newrow;
        colonna = newcol;
    
    elseif newcol < 1 || newcol > C || newrow < 1 || newrow > R || (griglia(newrow, newcol) ~= 1 && griglia(newrow, newcol)~=2 && griglia(newrow, newcol)~=3)
        % Stato invalido: uscito dai bordi o collisione
        % Seleziona un indice casuale tra gli stati iniziali
        disp('Posizione non valida: resetto stato.');
        indice = randi(length(statiInizialiX)); % Scegli un indice casuale
        sp = [statiInizialiX(indice), statiInizialiY(indice)]; % Stato iniziale
        r = -1; % Reward negativo
        newvel_x = 0;
        newvel_y = 0;
        riga = statiInizialiY(indice);
        colonna = statiInizialiX(indice);
        return; % Termina l'episodio e passa al successivo
    else
        % Stato valido: aggiorna la posizione
        sp = [newcol, newrow]; % Nuova posizione come vettore
        riga = newrow;
        colonna = newcol;
    end
end
