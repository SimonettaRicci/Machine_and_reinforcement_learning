function [griglia, coloredGrid] = crea_pista(R, C)
    % Crea una griglia vuota (0 = fuori pista, 1 = pista)
    griglia = zeros(R, C);
    
    % Impostare gli elementi interni alla pista (forma a "L")
    griglia(:, 2:13) = 1;
    griglia(2:9, :) = 1;
    
    % Impostare i bordi
    griglia(1, 2:13) = 0;     % Bordo superiore
    griglia(2:9, 1) = 0;       % Bordo sinistro
    
    % Alcuni fori e bordi speciali
    griglia(2, 2:3) = 0;
    griglia(3, 2:2) = 0;
    griglia(9:10, 2) = 0;
    griglia(14:17, 2) = 0;
    griglia(14:15, 3:3) = 0;

    griglia(15:18, 14) = 1;    % Alcune righe della pista
    griglia(17:18, 15) = 1;
    griglia(19:20, 14) = 1;
    griglia(10:11, 14) = 1;

    % Creazione della linea di partenza (verde) e traguardo (rosso)
    % 0 = grigio (fuori pista), 1 = bianco (pista), 2 = partenza (verde), 3 = traguardo (rosso)
    coloredGrid = griglia;  % Copia della griglia originale
    coloredGrid(end, 2:13) = 3;  % Linea di partenza (rosso)
    coloredGrid(2:9, end) = 2;   % Linea di arrivo (verde)

    % Visualizzazione della griglia
    figure;
    imagesc(coloredGrid); 
    colormap([0.5 0.5 0.5; 1 1 1; 0 1 0; 1 0 0]); % Colori: Grigio, Bianco, Verde, Rosso
    axis equal;  % Mantieni proporzioni corrette
    axis tight;  % Rimuove spazio vuoto intorno alla griglia
    title('Pista');
    
    % Aggiungi la griglia visibile
    grid on;
    set(gca, 'XTick', 0.5:1:C+0.5, ...
             'YTick', 0.5:1:R+0.5, ...
             'XTickLabel', [], 'YTickLabel', [], ...
             'GridColor', 'k', 'GridAlpha', 1);
end
