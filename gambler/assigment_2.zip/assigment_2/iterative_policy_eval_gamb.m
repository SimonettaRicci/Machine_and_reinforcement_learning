function vpi = iterative_policy_eval_gamb(P,R,policy,gamma,vpi0)
    % % computes the value function of policy pi by iterative policy evaluation
    % 
    % % set tolerance
    % delta = 1;
    % 
    % %S = size(P, 1);
    % S=101;
    % 
    % % transition probability matrix
    % Ppi = zeros(S,S);
    % % reward vector
    % Rpi = zeros(S,1);
    % for s = 1:S
    %     % matrices can be constructed row by row
    %     Ppi(s, :) = P(s, :, policy(s));
    %     Rpi(s) = R(s,policy(s)); 
    % end
    % 
    % % initialize the value of the policy
    % vpi = vpi0;
    % while true
    %     % synchronous value update
    %     vpinew = Rpi + gamma*Ppi*vpi;
    %     if norm(vpi - vpinew, inf) < toll
    %         vpi = vpinew;
    %         break;
    %     else
    %         vpi = vpinew;
    %     end
    % end
    
    % Parameters
    S = size(P, 1); % Number of states
    vpi = zeros(1, S); % Initialize value function
    
    % Convergence threshold
    % The value of delta ensures that the iterative process stops when the
    % maximum change in the value function (deltaMax) across all states is
    % smaller than this threshold. This guarantees that the function has
    % effectively converged to a stable solution, within a margin of error.
    
    % Delta should be chosen to balance precision and computation time.
    % - A smaller delta (e.g., 1e-8) results in higher precision but may increase iterations.
    % - A larger delta (e.g., 1e-4) speeds up computation but reduces precision.
    % Choose delta based on the problem's tolerance for approximation errors.
    
    delta = 1;
    
    while true
        deltaMax = 0;
        % Iterate over all states
        for s = 1:S
            a = policy(s); % Action prescribed by the policy
            % Compute expected value for state s under the current policy
            v_new = R(s, a) + gamma * sum(P(s, :, a) .* vpi);
            % Update the maximum change in value
            deltaMax = max(deltaMax, abs(v_new - vpi(s)));
            % Update value function for state s
            vpi(s) = v_new;
        end
        % Check for convergence
        if deltaMax < delta
            break;
        end
    end
end


