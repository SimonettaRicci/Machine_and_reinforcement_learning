clear all
close all
clc

rng(1)
load gambler_model.mat
gamma = 0.9; %l'unicità della soluzione è garantita per gamma<1

% number of states
S = size(P, 1);
% number of actions
A = size(P, 3);


policy = randi(A, [S, 1]);

%tic
vpi = policy_evaluation_gamb(P,R,policy,gamma);
%toc

vpi0 = zeros(S,1);

%tic
vpi2 = iterative_policy_eval_gamb( ...
    P,R,policy,gamma,vpi0);
%toc

% n1 = 30;
% n2 = 30;

% XX = zeros(S, S);
% YY = zeros(S, S);
% ZZ = zeros(S, S);
% PP = zeros(S, S);
% for s = 1:S
%     [num1, num2] = ind2sub([n1+1 n2+1], s);
%     XX(s, s) = s;
%     YY(s,s) = s;
%     ZZ(s) = vpi(s);
%     PP(s) = policy(s);
% end
% 
% plot the policy
% figure()
% contourf(XX,YY,PP,1:A)
% 
% % plot the value function
% figure()
% surf(XX,YY,ZZ)

figure(1)
plot([1:99],policy(2:100))
grid on
figure(2)
plot([0:100],vpi)
grid on

