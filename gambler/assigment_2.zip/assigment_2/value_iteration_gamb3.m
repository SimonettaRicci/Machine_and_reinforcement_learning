clear all
close all
clc

rng(123)
load gambler_model.mat
gamma = 0.99;
theta = 1e-6;

% number of states
S = size(P, 1);
% number of actions
A = size(P, 3);

% Parameters for Value Iteration
v = zeros(S, 1); % Initialize value function
policy = zeros(S, 1); % Initialize policy
delta = Inf;     % Initialize delta

% Value Iteration Loop
iteration = 0;   % Count the number of iterations
while delta > theta
    iteration = iteration + 1;
    delta = 0;
    v_new = zeros(S, 1); % Temporary array for updated values

    for s = 1:S
        q = zeros(A, 1); % Temporary array for action values
        for a = 1:A
            q(a) = R(s, a) + gamma * P(s, :, a) * v; % Compute Q(s, a)
        end
        v_new(s) = max(q); % Update the value function
        policy(s) = find(q == max(q), 1, 'first'); % Update policy
        delta = max(delta, abs(v_new(s) - v(s))); % Update delta
    end

    v = v_new; % Update value function
    fprintf('Iteration %d, Delta: %.6f\n', iteration, delta); % Monitor convergence
end

% Display results
disp('Optimal Policy:');
disp(policy');
disp('Value Function:');
disp(v');

% Visualization
figure(1);
plot(2:S-1, policy(2:S-1), 'LineWidth', 2);
title('Optimal Policy');
xlabel('State');
ylabel('Optimal Action');
grid on;

figure(2);
plot(1:S, v, 'LineWidth', 2);
title('Value Function');
xlabel('State');
ylabel('Value');
grid on;
