clear all;
close all;
clc;

% Parameters
S = 101;  % Number of states (0 to goal, inclusive)
A = S - 2; % Maximum number of actions (all possible bets except terminal states)

%%

% creazione modello

%matrice di transizione degli stati P non troncate->value iteration
% P=zeros(S, S, A); %matrice 101x101x99
% 
% for s=1:S %da 1 a 101 compreso 
% 
%     for a=1:A 
%     
%         %se provo a scommettere più di quello che ho, scommetto il massimo
%         %che ho nello stato
%         bet=min(a, s-1); %non posso scommettere piu di quello che ho
% 
%         %stati terminali
%         if s==1 || s==S
%             P(s, s, a)=1;
%             
%         %stati non terminali    
%         else
%             spp=s+bet; %nel caso vincessi/uscisse testa
%             spm=s-bet; %nel caso perdessi/uscisse croce
%             
%             %saturate/bound
%             spp=min(spp, S); %non posso andare oltre lo stato 101
%             %spm=max(spm, 1); inutile perche gia messo il fatto che non posso scommettere piu di quel che ho 
%             % non posso andare oltre lo stato 1
%     
%             P(s, spp, a)=P(s, spp, a) + 1/2;
%             P(s, spm, a)=P(s, spm, a) + 1/2;
%         end
% 
% 
%     end
% 
% end
%%
%creare delle matrici P troncate, dove per ogni stato non posso giocare piu
%azioni dei soldi che ho->policy iteration

% Transition matrices
P = zeros(S, S, A);  % Transition probabilities
for s = 2:S-1  % Only non-terminal states
    % for a = 1:min(s-1, S-s)  % Valid bets for current state
    %     P(s, s + a, a) = 1/2;  % Win
    %     P(s, s - a, a) = 1/2;  % Lose
    % end

    %stati non terminali
    for a=1:s-1 %non posso utilizzare le azioni in cui scommetto più di quel che ho

        spp=s+a; %nel caso vincessi/uscisse testa
        spm=s-a; %nel caso perdessi/uscisse croce

        %saturate/bound
        spp=min(spp, S); %non posso andare oltre lo stato 101

        P(s, spp, a)=P(s, spp, a) + 1/2;
        P(s, spm, a)=P(s, spm, a) + 1/2;
    end
end

% Terminal states stay in place
P(1, 1, :) = 1;       % Losing state
P(S, S, :) = 1;       % Winning state

% Reward matrix
R = zeros(S, A);  % Rewards for each state-action pair
earn = zeros(S, 1);
earn(1) = -1;     % Losing state reward
earn(end) = 1;      % Winning state reward

for a = 1:A
    R(:, a) = P(:, :, a) * earn;  % Compute expected rewards for each action
end

% Display example values
disp('Transition matrix P for state 50 and action 5:');
disp(P(50, :, 5));
disp('Reward matrix R for state 50:');
disp(R(50, :));

% Save model
save('gambler_model.mat', 'P', 'R');