function vpi = policy_evaluation_gamb(P,R,policy,gamma)
    % Parameters
    S = size(P, 1); % Number of states
    
    % Initialize P_pi and R_pi
    P_pi = zeros(S, S); % Aggregated transition matrix under policy
    R_pi = zeros(S, 1); % Reward vector under policy
    
    % Build P_pi and R_pi
    for s = 1:S
        a = policy(s);          % Action prescribed by the policy
        P_pi(s, :) = P(s, :, a); % Transition probabilities for state s under action a
        R_pi(s) = R(s, a);       % Reward for state s under action a
    end
    
    % Solve the linear system (I - gamma * P_pi) * V = R_pi
    vpi = (eye(S) - gamma * P_pi) \ R_pi;

end