function [vpin, policy] = value_iteration_gamb(P,R,gamma,vpi)
S = size(P, 1);
A = size(P, 3);
% initialize matrices
q = zeros(S,A);
vpin = zeros(S,1);
policy = zeros(S,1);

% we loop for all the state
for s = 1:S 
    for a = 1:A
        q(s,a) = R(s,a) + gamma*P(s,:,a)*vpi;
    end
    % synchronous substitution
    vpin(s) = max(q(s,:));
    policy(s) = find(q(s,:) == max(q(s,:)),1,"first");
end
