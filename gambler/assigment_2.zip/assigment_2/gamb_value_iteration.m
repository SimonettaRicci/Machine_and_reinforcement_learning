clear all
close all
clc

rng(123)
load gambler_model.mat
gamma = 0.99;
theta = 1e-6;

% number of states
S = size(P, 1);
% number of actions
A = size(P, 3);

vpi = zeros(S,1);
% tic
while true
    % perform a value iteration step
    [vpin, policy] = value_iteration_gamb2(P,R,gamma,vpi);

    % condition to interrupt the iteration - value function converged
    if norm(vpin - vpi,inf) < theta
        break;
    else
        vpi = vpin;
    end
end
% toc

% plot the obtained results

% n1 = 30;
% n2 = 30;
% 
% XX = zeros(S, 1);
% YY = zeros(S, 1);
% ZZ = zeros(S, S);
% PP = zeros(S, 1);
% % 
% for s = 1:S
% %     [num1, num2] = ind2sub([n1+1 n2+1], s);
%      XX(s) = s;
%      YY(s) = s;
%     ZZ(s) = vpi(s);
%     PP(s) = policy(s);
% end
% 
% % plot the policy
% figure(1)
% contourf(XX,YY,PP,1:A)
% 
% % plot the value function
% figure(2)
% surf(XX,YY,ZZ)

figure(1)
plot([1:99],policy(2:100))
grid on
figure(2)
plot([0:100],vpi)
grid on