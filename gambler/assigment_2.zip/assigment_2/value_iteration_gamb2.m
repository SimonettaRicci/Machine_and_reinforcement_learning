function [vpin, policy] = value_iteration_gamb2(P, R, gamma, vpi)
    % VALUE_ITERATION_GAMB: Calcola un passo della Value Iteration.
    % INPUT:
    %   P      - Matrice di probabilità di transizione (S x S x A)
    %   R      - Matrice di ricompense (S x A)
    %   gamma  - Fattore di sconto
    %   vpi    - Funzione di valore corrente (S x 1)
    % OUTPUT:
    %   vpin   - Nuova funzione di valore (S x 1)
    %   policy - Politica ottimale aggiornata (S x 1)
    
    % Numero di stati e azioni
    S = size(P, 1);
    A = size(P, 3);
    
    % Inizializza vettori
    vpin = zeros(S, 1);
    policy = zeros(S, 1);
    
    % Ciclo per ogni stato
    for s = 1:S
        % Calcola q(s, a) per tutte le azioni
        q = zeros(1, A);
        for a = 1:A
            q(a) = R(s, a) + gamma * (P(s, :, a) * vpi);
        end
        
        % Trova il massimo di q(s, a) e l'azione corrispondente
        % synchronous substitution
        vpin(s) = max(q(s,:));
        policy(s) = find(q(s,:) == max(q(s,:)),1,"first");
    end

end
